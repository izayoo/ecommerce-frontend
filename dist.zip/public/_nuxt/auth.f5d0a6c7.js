import{$ as e,k as o}from"./entry.1a28b290.js";const s=e(async a=>{const t=o();localStorage.getItem("token")||t.push("/")});export{s as default};
